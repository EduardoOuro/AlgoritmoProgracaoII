package testaponto;

public class Ponto {
    private int x,y;
    
    public Ponto ( int x, int y ){
        this.x = x;
        this.y = y;
    }
    public Ponto (){
        this.x = 0;
        this.y = 0;
    }

    public boolean igual(Ponto p) {
        //x de p1 e p.x eh o x de p2
        return this.x == p.x && this.y == p.y;
           
    }
}