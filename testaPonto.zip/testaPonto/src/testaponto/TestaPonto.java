
package testaponto;
// classe cliente que utiliza e testa os objetos da classe ponto
public class TestaPonto {
   public static void main(String[] args) {
       Ponto p1,p2; // variável de referencia
       
       // Instanciar um objeto Ponto
       p1 = new Ponto(10,11);
       p2 = new Ponto(10,11);
       // p1 = passado como parametro de forma implicita
       // p2 = passado como parametro de forma explicita
       p1.igual(p2);
       System.out.println(p1.igual(p2));
       
        
   }
    
}
