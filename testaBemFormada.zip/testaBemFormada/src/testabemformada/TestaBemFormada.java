
package testabemformada;

/**
 *
 * @author fabio.aglubacheski
 */
public class TestaBemFormada {

  
    public static void main(String[] args) {
        //String entrada="(()[()])";
        //String entrada="([)]";
        //String entrada="((())";
        String entrada="())";
        System.out.println("Para entrada "+entrada+" bemFormada="+bemFormada(entrada));
    }

    private static boolean bemFormada(String entrada) {
        // vetor de caractares para representar minha 
        // estrutura de dados pilha
        char pilha[]=new char[entrada.length()];
        int topo = -1; // define que a pilha estah vazia
        
        // anda na string 
        for( int i=0; i < entrada.length();i++){
            // verifica se na string temos um abre ( ou [
            if( entrada.charAt(i) == '(' ||entrada.charAt(i) == '['){
                // empilha o simbolo
                pilha[++topo]= entrada.charAt(i);
            }
            else{ // provavelmente eh um fecha ) ou ]
                // testa se a pilha nao estah vazia, se estiver
                // retorna falso
                if( topo == -1)
                    return false;
                // desempilha o simbolo no topo da pilha
                char c = pilha[topo--];
                if(entrada.charAt(i) == ')' ){
                    // se veio um abre ( e no topo tem um fecha )
                    // esta tudo certo, caso contrario ja podemos
                    // retornar que nao esta bem formada
                    if( c != '(')
                        return false;
                } else if(entrada.charAt(i) == ']' ){
                    // se veio um abre [ e no topo tem um fecha ]
                    // esta tudo certo, caso contrario ja podemos
                    // retornar que nao esta bem formada
                    if( c != '[')
                        return false;
                }
            }
        }
        // finalizei a analise da string, so precisamos testar
        // se a pilha esta vazia
        return topo == -1;
    }
    
}
