/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testafatorial;

/**
 *
 * @author fabio.aglubacheski
 */
public class TestaFatorial {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("calculo do fatorial:"+fatorial(4));
    }
    public static int fatorial( int n){
        if ( n == 0 )
            return 1;
        else{
            int fatAnterior = fatorial(n-1);
            int fatRetorno = n*fatAnterior;
            return fatRetorno;
        }
    }
    
}
