
package fracaoestruturada;

import java.util.Scanner;

public class FracaoEstruturada {

    public static void main(String[] args) {
       Scanner ler = new Scanner(System.in);
       // 1o fracao
       int a, b;
       // 2a fracao
       int c, d;
       System.out.print("Digite numerador da 1a fracao:");
       a = ler.nextInt();
       
       System.out.print("Digite denominador da 1a fracao:");
       b = ler.nextInt();
               
       System.out.print("Digite numerador da 2a fracao:");
       c = ler.nextInt();
       
       System.out.print("Digite denominador da 2a fracao:");
       d = ler.nextInt();
       
       if(  a * d == b * c )
           System.out.println("fracoes iguais");
       else 
           System.out.println("fracoes diferentes");
       
       
       
    }
    
}
