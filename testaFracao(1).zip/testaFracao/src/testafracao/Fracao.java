package testafracao;

// TAD Fracao representado usando uma classe
public class Fracao {
    // atributos encapsulados=privados
    private int num, den;
    // construtor da classe, tem o mesmo nome da classe e parece
    // um método, mas nao é.
    public Fracao( int num, int den){
        this.num = num;
        this.den = den;
        
    }
    // outro construtor
    public Fracao(){
        this.num = 0;
        this.den = 0;
    }
    // metodo verifica se duas fracoes sao iguais
    // Igualdade: (a/b)== (c/d) se a*d == b*c
    public boolean igual(Fracao f){
        return this.num*f.den == this.den*f.num;
    }
    // soma duas fracoes e retorna uma nova fracao com o resultado
    // Soma de fração: (a/b)+(c/d)=( (a.d+c.b) / b.d )
    public Fracao soma( Fracao f ){
      //              a . d    +   c   .    b  
      int num = this.num*f.den + f.num * this.den;
      //             b  .  d
      int den = this.den*f.den;
      Fracao nova = new Fracao( num, den );
      return nova;
    }
    public String mostre() {
        return this.num+"/"+this.den;
    }
}
