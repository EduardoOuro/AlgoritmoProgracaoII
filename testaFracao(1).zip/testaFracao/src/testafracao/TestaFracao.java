package testafracao;

public class TestaFracao {
    // aplicacao cliente para testar a fracao
    public static void main(String[] args) {
        // declaracao de uma variavel de referemcoa que ira
        // receber um objeto Fracao
        Fracao f1, f2;
        // instanciando um objeto da classe Fracao
        f1 = new Fracao(1,2); // Fracao() eh o construtor
        System.out.println("fracao="+f1.mostre());
        
        f2 = new Fracao(3,5); // Fracao() eh o construtor
        System.out.println("fracao="+f2.mostre());
        
        Fracao f3 = f1.soma(f2);
        System.out.println("fracao 3="+f3.mostre());
        
    }

    
}
